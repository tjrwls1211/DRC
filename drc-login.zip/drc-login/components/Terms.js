import React, {useState, useEffect}  from 'react';

function Terms(){

  const [useCheck, setUseCheck] = useState(false);

  const useBtnEvent =()=>{
    if(useCheck === false) {
      setUseCheck(true)
    }else {
      setUseCheck(false)
    }
  };

  return (
    <form method="post" action="" className={styles.form}>
      <div className={styles.form_agreement}>
        <label className={styles.form_agreement_title}>
        	약관동의
        </label>
        <div className={styles.form_agreement_box}>
        	<div className={styles.form_agreement_item}>
        		<input type="checkbox" id="check2" checked={useCheck}  onChange={useBtnEvent}/>
        		<label for="check2">이용약관 <span className={styles.blue}>(필수)</span></label>
        	</div>
        </div>
      </div>
      <button type="submit" className={`${styles.btn_primary} ${styles.btn_55} ${styles.btn_submit}`}>
      	회원가입하기
      </button>
    </form>
  )
}

export default Terms;